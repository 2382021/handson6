
const Post = () => {
  return (
    <div>Post Page</div>
  )
}

export default Post