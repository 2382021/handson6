
const Carts = () => {
  return (
    <div>Carts Page</div>
  )
}

export default Carts